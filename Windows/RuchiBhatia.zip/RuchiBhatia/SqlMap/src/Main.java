import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        String baseUrl = "http://localhost/SqlMapTest/login.php";
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\dell\\Desktop\\CSS\\RuchiBhatia\\SqlMap\\resources\\chromedriver_win.exe");
        System.setProperty("webdriver.chrome.silentOutput", "true");
        Logger.getLogger("org.openqa.selenium").setLevel(Level.OFF);
        ChromeOptions options = new ChromeOptions();
        options.addArguments("headless");
        options.addArguments("window-size=1200x600");
        WebDriver driver = new ChromeDriver(options);
        driver.get(baseUrl);
        driver.findElement(By.id("login-username")).sendKeys("' OR '1' = '1");
        driver.findElement(By.id("login-password")).sendKeys("' OR '1' = '1");
        driver.findElement(By.id("login-button")).click();
        if(!driver.getCurrentUrl().equals(baseUrl)) {
            System.out.println("SQL injection vulnerability found for the website : " + baseUrl);
        } else {
            System.out.println("No vulnerabilities found for the website : " + baseUrl);
        }



    }
}
